<?php
	# Mantis - a php based bugtracking system
	# Copyright (C) 2000, 2001  Kenzaburo Ito - kenito@300baud.org
	# This program is distributed under the terms and conditions of the GPL
	# See the files README and LICENSE for details

	###########################################################################
	# CONFIGURATION VARIABLES
	###########################################################################

	# default/config_inc2.php

	#----------------------------------
	# specifiy your top/bottom include file (logos, banners, etc)
	$g_bottom_include_page            = $g_absolute_path."";
	$g_top_include_page               = $g_absolute_path."";
	# css
	$g_css_include_file               = $g_absolute_path."css_inc".$g_php;
	# meta tags
	$g_meta_include_file              = $g_absolute_path."meta_inc".$g_php;
	#----------------------------------
	# core file variables
	$g_core_API_file                  = $g_absolute_path."core_API".$g_php;
	#----------------------------------

	#----------------------------------
	# misc
	$g_index                          = $g_path."index".$g_php;
	$g_main_page                      = $g_path."main_page".$g_php;
	#----------------------------------

	#----------------------------------
	# account
	// change for phpcollab any user related admin work should be done from phpcollab 
	#$g_account_page                   = $g_path."account_prof_menu_page".$g_php;

	$g_account_page                   = $g_path."account_page".$g_php;
	$g_account_update                 = $g_path."account_update".$g_php;
	$g_account_delete_page            = $g_path."account_delete_page".$g_php;
	$g_account_delete                 = $g_path."account_delete".$g_php;
	#----------------------------------

	#----------------------------------
	# account profiles
	$g_account_profile_menu_page      = $g_path."account_prof_menu_page".$g_php;
	$g_account_profile_add            = $g_path."account_prof_add".$g_php;
	$g_account_profile_edit_page      = $g_path."account_prof_edit_page".$g_php;
	$g_account_profile_update         = $g_path."account_prof_update".$g_php;
	$g_account_profile_delete         = $g_path."account_prof_delete".$g_php;
	$g_account_profile_make_default   = $g_path."account_prof_make_default".$g_php;
	#----------------------------------

	#----------------------------------
	# account prefs
	$g_account_prefs_page             = $g_path."account_prefs_page".$g_php;
	$g_account_prefs_update           = $g_path."account_prefs_update".$g_php;
	$g_account_prefs_reset            = $g_path."account_prefs_reset".$g_php;
	#----------------------------------

	#----------------------------------
	# bug
	$g_bug_assign                     = $g_path."bug_assign".$g_php;

	$g_bug_file_add                   = $g_path."bug_file_add".$g_php;

	$g_bug_delete_page                = $g_path."bug_delete_page".$g_php;
	$g_bug_delete                     = $g_path."bug_delete".$g_php;
	$g_bug_update_page                = $g_path."bug_update_page".$g_php;
	$g_bug_update_advanced_page       = $g_path."bug_update_advanced_page".$g_php;
	$g_bug_update                     = $g_path."bug_update".$g_php;

	$g_bug_reopen_page                = $g_path."bug_reopen_page".$g_php;
	$g_bug_reopen                     = $g_path."bug_reopen".$g_php;

	$g_bug_close_page                 = $g_path."bug_close_page".$g_php;
	$g_bug_close                      = $g_path."bug_close".$g_php;

	$g_bug_resolve                    = $g_path."bug_resolve".$g_php;
	$g_bug_resolve_page               = $g_path."bug_resolve_page".$g_php;
	$g_bug_vote_add                   = $g_path."bug_vote_add".$g_php;

	$g_bug_monitor                    = $g_path."bug_monitor".$g_php;
	#----------------------------------

	#----------------------------------
	# bugnote
	$g_bugnote_add                    = $g_path."bugnote_add".$g_php;
	$g_bugnote_delete                 = $g_path."bugnote_delete".$g_php;
	$g_bugnote_edit_page              = $g_path."bugnote_edit_page".$g_php;
	$g_bugnote_update                 = $g_path."bugnote_update".$g_php;
	#----------------------------------

	#----------------------------------
	# bugnote includes
	$g_bugnote_include_file           = $g_absolute_path."bugnote_inc.php";
	#----------------------------------

	#----------------------------------
	# login
	$g_login                          = $g_path."login".$g_php;
	$g_login_anon                     = $g_path."login_anon".$g_php;
#	$g_login_page                     = $g_path."login_page".$g_php;
	$g_login_page                     = $g_phpcollab_path."login".$g_php;
	$g_login_error_page               = $g_path."login_error_page".$g_php;
	$g_login_success_page             = $g_path."index".$g_php;
	$g_login_select_proj_page         = $g_path."login_select_proj_page".$g_php;
	$g_logout_page                    = $g_path."logout_page".$g_php;
	#$g_logout_redirect_page           = $g_path."login_page".$g_php;
	$g_logout_redirect_page           = $phpcollab_url_cookie;
	#----------------------------------

	# documentation
	$g_documentation_html             = $g_path."doc/documentation.html";

	#----------------------------------
	# site management
	$g_manage_page                    = $g_path."manage_page".$g_php;
	$g_manage_create_new_user         = $g_path."manage_create_new_user".$g_php;
	$g_manage_create_user_page        = $g_path."manage_create_user_page".$g_php;
	#----------------------------------

	$g_manage_prune                   = $g_path."manage_prune".$g_php;

	#----------------------------------
	$g_manage_user_page               = $g_path."manage_user_page".$g_php;
	$g_manage_user_update             = $g_path."manage_user_update".$g_php;
	$g_manage_user_reset              = $g_path."manage_user_reset".$g_php;
	$g_manage_user_delete_page        = $g_path."manage_user_delete_page".$g_php;
	$g_manage_user_delete             = $g_path."manage_user_delete".$g_php;
	$g_manage_user_proj_delete        = $g_path."manage_user_proj_delete".$g_php;
	$g_manage_user_proj_add           = $g_path."manage_user_proj_add".$g_php;
	#----------------------------------

	#----------------------------------
	# userland documentation
	$g_documentation_page             = $g_path."documentation_page".$g_php;
	$g_usage_doc_page                 = $g_path."documentation.html";
	#----------------------------------

	#----------------------------------
	$g_set_project                    = $g_path."set_project".$g_php;
	#----------------------------------

	#----------------------------------
	# multiple projects
	$g_proj_doc_add_page              = $g_path."proj_doc_add_page".$g_php;
	$g_proj_doc_add                   = $g_path."proj_doc_add".$g_php;
	$g_proj_doc_delete_page           = $g_path."proj_doc_delete_page".$g_php;
	$g_proj_doc_edit_page             = $g_path."proj_doc_edit_page".$g_php;
	$g_proj_doc_page                  = $g_path."proj_doc_page".$g_php;
	$g_proj_doc_update                = $g_path."proj_doc_update".$g_php;
	#----------------------------------

	#----------------------------------
	# multiple projects
	$g_manage_project_menu_page       = $g_path."manage_proj_menu_page".$g_php;
	$g_manage_project_add             = $g_path."manage_proj_add".$g_php;
	$g_manage_project_edit_page       = $g_path."manage_proj_edit_page".$g_php;
	$g_manage_project_update          = $g_path."manage_proj_update".$g_php;
	$g_manage_project_delete          = $g_path."manage_proj_delete".$g_php;
	$g_manage_project_delete_page     = $g_path."manage_proj_delete_page".$g_php;
	#----------------------------------

	#----------------------------------
	# project versions
	$g_manage_project_version_add         = $g_path."manage_proj_ver_add".$g_php;
	$g_manage_project_version_delete      = $g_path."manage_proj_ver_delete".$g_php;
	$g_manage_project_version_delete_page = $g_path."manage_proj_ver_del_page".$g_php;
	$g_manage_project_version_edit_page   = $g_path."manage_proj_ver_edit_page".$g_php;
	$g_manage_project_version_update      = $g_path."manage_proj_ver_update".$g_php;
	#----------------------------------

	#----------------------------------
	# project category
	$g_manage_project_category_add         = $g_path."manage_proj_cat_add".$g_php;
	$g_manage_project_category_copy        = $g_path."manage_proj_cat_copy".$g_php;
	$g_manage_project_category_delete      = $g_path."manage_proj_cat_delete".$g_php;
	$g_manage_project_category_delete_page = $g_path."manage_proj_cat_del_page".$g_php;
	$g_manage_project_category_edit_page   = $g_path."manage_proj_cat_edit_page".$g_php;
	$g_manage_project_category_update      = $g_path."manage_proj_cat_update".$g_php;
	#----------------------------------

	#----------------------------------
	# news
	$g_news_menu_page                 = $g_path."news_menu_page".$g_php;
	$g_news_edit_page                 = $g_path."news_edit_page".$g_php;
	$g_news_add                       = $g_path."news_add".$g_php;
	$g_news_update                    = $g_path."news_update".$g_php;
	$g_news_delete_page               = $g_path."news_delete_page".$g_php;
	$g_news_delete                    = $g_path."news_delete".$g_php;

	$g_news_list_page                 = $g_path."news_list_page".$g_php;
	$g_news_view_page                 = $g_path."news_view_page".$g_php;
	#----------------------------------

	#----------------------------------
	# project documents
	$g_proj_doc_add                   = $g_path."proj_doc_add".$g_php;
	$g_proj_doc_add_page              = $g_path."proj_doc_add_page".$g_php;
	$g_proj_doc_delete                = $g_path."proj_doc_delete".$g_php;
	$g_proj_doc_delete_page           = $g_path."proj_doc_delete_page".$g_php;
	$g_proj_doc_edit_page             = $g_path."proj_doc_edit_page".$g_php;
	$g_proj_doc_page                  = $g_path."proj_doc_page".$g_php;
	$g_proj_doc_update                = $g_path."proj_doc_update".$g_php;
	$g_proj_doc_view_page             = $g_path."proj_doc_view_page".$g_php;
	#----------------------------------

	$g_proj_user_add                  = $g_path."proj_user_add".$g_php;
	$g_proj_user_copy                 = $g_path."proj_user_copy".$g_php;
	$g_proj_user_delete               = $g_path."proj_user_delete".$g_php;
	$g_proj_user_update               = $g_path."proj_user_update".$g_php;
	$g_proj_user_menu_page            = $g_path."proj_user_menu_page".$g_php;

	#----------------------------------
	# report bug
	$g_report_bug_page                = $g_path."report_bug_page".$g_php;
	$g_report_bug_advanced_page       = $g_path."report_bug_advanced_page".$g_php;
	$g_report_add                     = $g_path."report_add".$g_php;
	#----------------------------------

	#----------------------------------
	# debug only
	$g_show_source_page               = $g_path."show_source_page".$g_php;
	#----------------------------------

	#----------------------------------
	#signup
	$g_signup_page                    = $g_path."signup_page".$g_php;
	$g_signup                         = $g_path."signup".$g_php;
	#----------------------------------

	#----------------------------------
	# summary
	$g_summary_page                       = $g_path."summary_page".$g_php;
	$g_summary_jpgraph_function           = $g_absolute_path."summary_graph_functions".$g_php;
	$g_summary_jpgraph_page               = $g_path."summary_jpgraph_page".$g_php;
	$g_summary_jpgraph_cumulative_bydate  = $g_path."summary_graph_cumulative_bydate".$g_php;
	$g_summary_jpgraph_bydeveloper        = $g_path."summary_graph_bydeveloper".$g_php;
	$g_summary_jpgraph_byreporter         = $g_path."summary_graph_byreporter".$g_php;
	$g_summary_jpgraph_byseverity         = $g_path."summary_graph_byseverity".$g_php;
	$g_summary_jpgraph_bystatus           = $g_path."summary_graph_bystatus".$g_php;
	$g_summary_jpgraph_byresolution       = $g_path."summary_graph_byresolution".$g_php;
	$g_summary_jpgraph_bycategory         = $g_path."summary_graph_bycategory".$g_php;
	$g_summary_jpgraph_bypriority         = $g_path."summary_graph_bypriority".$g_php;
	#----------------------------------

	#----------------------------------
	# bug view/update
	$g_view_all_bug_page              = $g_path."view_all_bug_page".$g_php;
	$g_view_all_include_file          = $g_absolute_path."view_all_inc".$g_php;

	$g_view_all_set                   = $g_path."view_all_set".$g_php;

	$g_view_bug_advanced_page         = $g_path."view_bug_advanced_page".$g_php;
	$g_view_bug_page                  = $g_path."view_bug_page".$g_php;
	$g_view_bug_inc                   = $g_absolute_path."view_bug_inc".$g_php;
	$g_bug_file_upload_inc            = $g_absolute_path."bug_file_upload_inc".$g_php;

	$g_file_download                  = $g_path."file_download".$g_php;
	#----------------------------------

	#----------------------------------
	# printing
	$g_print_all_bug_page             = $g_path."print_all_bug_page".$g_php;
	$g_print_bug_page                 = $g_path."print_bug_page".$g_php;
	$g_print_bugnote_include_file     = $g_absolute_path."print_bugnote_inc".$g_php;
	#----------------------------------

	#----------------------------------
	# New files
	$g_bug_file_delete                = $g_path."bug_file_delete".$g_php;
	$g_csv_export_inc                 = $g_path."view_csv_export_inc".$g_php;
	$g_view_all_bug_update            = $g_path."view_all_bug_update".$g_php;
	$g_jump_to_bug                    = $g_path."jump_to_bug".$g_php;
	#----------------------------------
?>
